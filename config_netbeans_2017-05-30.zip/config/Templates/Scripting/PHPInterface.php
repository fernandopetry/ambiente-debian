<?php

<#if namespace?? && namespace?length &gt; 0>
namespace ${namespace};
</#if>

/***                                             
 * 
 * 
 * Interface: ${name}
 * 
 * @filesource ${nameAndExt}
 * @package ${project.name}
 * @subpackage 
 * @category
 * @version v1.0
 * @since ${date} ${time}
 * @copyright (cc) 2017, Fernando Petry
 * 
 * @author Fernando Petry <fernandosouza2@gmail.com>                                                
 */

interface ${name} {
    
}